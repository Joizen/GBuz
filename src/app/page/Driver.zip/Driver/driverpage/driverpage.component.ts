import { Component,Input,EventEmitter, Output } from '@angular/core';
import { QRCodeModule } from 'angularx-qrcode';


@Component({
  selector: 'app-driverpage',
  templateUrl: './driverpage.component.html',
  styleUrls: ['./driverpage.component.scss']
})


export class DriverpageComponent {

  @Input() modal: any;
  @Input() viewData: any;
  @Output() repage: EventEmitter<any> = new EventEmitter<any>();

}
