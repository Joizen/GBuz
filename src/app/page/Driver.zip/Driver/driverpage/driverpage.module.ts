import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DriverpageRoutingModule } from './driverpage-routing.module';
import { MaterialModule } from '../../../material/material.module';
import { QRCodeModule } from 'angularx-qrcode';



@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    DriverpageRoutingModule,
    MaterialModule,
    QRCodeModule
  ]
})
export class DriverpageModule { }
