import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchdriverpageRoutingModule } from './searchdriverpage-routing.module';
import { SearchdriverPageComponent } from './searchdriverpage.component';
import { MaterialModule } from '../../../material/material.module';

import { DriverpageModule  } from '../../Driver/driverpage/driverpage.module';
import { DriverpageComponent } from '../../Driver/driverpage/driverpage.component';


// { path: 'driverdata', loadChildren: () => import('./page/Driver/driverpage/driverpage.module').then(m => m.DriverpageModule) },


@NgModule({
  declarations: [
    SearchdriverPageComponent,
    DriverpageComponent
  ],
  imports: [
    CommonModule,
    SearchdriverpageRoutingModule,
    MaterialModule,
    DriverpageModule,
  ],
  
})
export class SearchdriverpageModule { }
export interface  DriverModel { 
  id: number;
  driverfullname: string; 
  drivername: string;  
  surname: string;  
  nickname: string; 
  license: string; 
  licensetype: string;  
  phone: string; 
  mobile: string;  
  linename: string; 
  lineimage: string;  
}