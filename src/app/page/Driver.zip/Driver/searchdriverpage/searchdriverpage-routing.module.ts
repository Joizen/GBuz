import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SearchdriverPageComponent } from './searchdriverpage.component';
import { DriverpageComponent } from '../driverpage/driverpage.component';

const routes: Routes = [
  { path: '', component: SearchdriverPageComponent },
  { path: 'driver', component: DriverpageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SearchdriverpageRoutingModule { }
